window.registerExtension('sonarqubeplugin/test_page', function (options) {
  options.el.textContent = 'Hello SQ 6.5.....';
  return function () {};
});